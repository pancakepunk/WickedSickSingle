#include "Precompiled.h"
#include "ObjectFactoryPrecompiled.h"
#include "ComponentFactoryBase.h"

WickedSick::ComponentFactoryBase::ComponentFactoryBase()
{
}

WickedSick::ComponentFactoryBase::~ComponentFactoryBase()
{
}
