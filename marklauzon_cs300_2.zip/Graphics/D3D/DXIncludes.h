#pragma once


#include "d3d11.h"
#include "d3dcompiler.h"
#include "WICTextureLoader.h"