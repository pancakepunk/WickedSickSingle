#include "Precompiled.h"
//#include "MasterPrecompiled.h" //really need this
#include "DxTexture.h"
#include "Graphics/GraphicsInterface.h"
#include "Graphics/System/Graphics.h"
#include "Core/CoreInterface.h"

#include "Graphics/D3D/DXIncludes.h"
#include "Graphics/API/DirectX.h"
#include "Graphics/D3D/SwapChain.h"
#include "Graphics/D3D/Device.h"


namespace WickedSick
{
  DxTexture::DxTexture(const std::string & texName)
  : texture_view_(nullptr),
    Texture(texName)
  {
  }

  DxTexture::DxTexture(const std::vector<unsigned char>& tex)
  : texture_view_(nullptr),
    Texture(tex)
  {
    
  }

  DxTexture::~DxTexture()
  {
    Cleanup();
  }

  void DxTexture::Initialize()
  {
    Graphics* gSys = (Graphics*)Engine::GetCore()->GetSystem(ST_Graphics);
    DirectX* dx = (DirectX*)gSys->graphicsAPI;
    if(tex_.empty())
    {
      std::wstring wStrBecauseWhyNot(source_.begin(), source_.end());

      DxError(::DirectX::CreateWICTextureFromFile(dx->GetSwapChain()->device->D3DDevice,
                                                  wStrBecauseWhyNot.c_str(),
                                                  nullptr,
                                                  &texture_view_));
    }
    else
    {
      D3D11_TEXTURE2D_DESC desc;
      ZeroMemory(&desc, sizeof(D3D11_TEXTURE2D_DESC));
      desc.ArraySize = 1;
      desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
      desc.CPUAccessFlags = 0;
      desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
      desc.Height = 512;
      desc.Width = 512;
      desc.MipLevels = 0;
      desc.MiscFlags = 0;
      desc.SampleDesc.Count = 1;
      desc.SampleDesc.Quality = 0;
      desc.Usage = D3D11_USAGE_DEFAULT;

      D3D11_SUBRESOURCE_DATA texPass;
      texPass.pSysMem = &tex_[0];
      texPass.SysMemPitch = 512 * sizeof(unsigned char) * 4;
      texPass.SysMemSlicePitch = 512 * 512 * sizeof(unsigned char) * 4;
      ID3D11Texture2D* tex2d = nullptr;
      auto& device = dx->GetSwapChain()->device->D3DDevice;
      DxError(device->CreateTexture2D(&desc,
                                      NULL,
                                      &tex2d));
      dx->GetSwapChain()->device->D3DContext->UpdateSubresource(tex2d,
                                                                0,
                                                                nullptr,
                                                                &tex_[0],
                                                                512 * 4,
                                                                512 * 512 * 4);
      DxError(device->CreateShaderResourceView(tex2d,
                                               nullptr,
                                               &texture_view_));

    }
   
  }

  void DxTexture::Cleanup()
  {
    texture_view_->Release();
  }

  void* DxTexture::GetTexturePointer()
  {
    return (void*)texture_view_;
  }
}


