#pragma once
#include "Math/MathInterface.h"
namespace WickedSick
{
  class Texture
  {
  public:
    Texture(const std::string& source);
    Texture(const std::vector<unsigned char>& tex);
    virtual ~Texture();
    virtual void* GetTexturePointer() = 0;
    virtual void Initialize() = 0;
    virtual std::string GetName() final;
    virtual std::string GetSource() final;
  protected:
    std::string name_;
    std::string source_;
    std::vector<unsigned char> tex_;
  };
}