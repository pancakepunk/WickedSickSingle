#pragma once

#include "Vertex.h"


namespace WickedSick
{
  struct Face
  {
    Vector3i  indices;
    //Vector3   normal;
  };
}
