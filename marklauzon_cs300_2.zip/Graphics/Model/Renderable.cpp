#include "Precompiled.h"
#include "GraphicsPrecompiled.h"
#include "Renderable.h"

namespace WickedSick
{
  Renderable::Renderable() 
  : vertBuf(nullptr)
  {

  }
}