#include "Precompiled.h"
#include "GraphicsPrecompiled.h"
#include "Model/Loaders/ModelLoader.h"

namespace WickedSick
{
  ModelLoader::ModelLoader()
  {

  }

  ModelLoader::~ModelLoader()
  {

  }
}