#pragma once


typedef long HRESULT;
namespace WickedSick
{
  void DxError(const HRESULT& retVal);
}
