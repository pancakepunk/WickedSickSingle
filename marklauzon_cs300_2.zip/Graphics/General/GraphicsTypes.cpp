#include "Precompiled.h"
#include "GraphicsPrecompiled.h"
#include "GraphicsTypes.h"
#include "meta/MetaInterface.h"

RegisterEnum(WickedSick, LightType, Enum, Count)
}

RegisterEnum(WickedSick, ShaderType, Enum, Count)
}

RegisterEnum(WickedSick, AccessType, Enum, Count)
}

RegisterEnum(WickedSick, UsageType, Enum, Count)
}

RegisterEnum(WickedSick, DrawType, Enum, Count)
}