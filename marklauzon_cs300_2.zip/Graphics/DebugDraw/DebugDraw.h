#pragma once

namespace WickedSick
{
  class DebugDraw
  {
    
  };
}