#pragma once

#include "meta/Utility/MetaMacros.h"
#include "meta/Type/MetaSingleton.h"
