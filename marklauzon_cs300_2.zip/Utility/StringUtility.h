#pragma once



#include "UtilityInterface.h"






namespace WickedSick
{
  std::string TrimSpaces(std::string toTrim);

  

}
