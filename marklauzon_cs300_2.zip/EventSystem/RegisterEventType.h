RegisterType(Keyboard)
RegisterType(Mouse)
RegisterType(Quit)
