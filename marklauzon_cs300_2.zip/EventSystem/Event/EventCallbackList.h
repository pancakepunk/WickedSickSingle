#pragma once



namespace WickedSick
{
  class Event;
  void QuitEvent(Event*);
}
