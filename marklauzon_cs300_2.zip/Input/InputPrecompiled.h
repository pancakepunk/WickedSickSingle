#pragma once

#define NOMINMAX
#include <windows.h>

#define MaxKeys VK_OEM_CLEAR