RegisterReason(Exception)
RegisterReason(TookTooLong)
RegisterReason(LogicError)
RegisterReason(DidNotFail)
