#pragma once

namespace WickedSick
{
  enum WindowType
  {
    WT_Windowed,
    WT_BorderlessWindowed,
    WT_Fullscreen,
    WT_BorderlessFullscreen,
    WT_Count
  };
}
