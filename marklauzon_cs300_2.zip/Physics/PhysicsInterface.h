#pragma once

#include "Physics/System/Physics.h"
#include "Physics/Components/PhysicsComponent.h"
#include "Physics/Architecture/PhysicsScene.h"
#include "Physics/Components/OrbitComponent.h"
