#pragma once

namespace WickedSick
{
  struct AABB  
  {

    Vector3 min_;
    Vector3 max_;
  };
}
