#pragma once
namespace WickedSick
{
  class BroadPhase
  {
    public:
    private:
  };
}
