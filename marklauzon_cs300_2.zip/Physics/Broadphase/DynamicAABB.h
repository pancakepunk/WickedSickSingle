#pragma once

namespace WickedSick
{
  class DynamicAABB : public Broadphase
  {
    public:
    private:
  };
}

#endif
