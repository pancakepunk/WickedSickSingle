#pragma once

#define NOMINMAX

#include <windows.h>
#include <math.h>
